package com.example.diaryofemotions;

import static com.example.diaryofemotions.global_variable.eml_global;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class calendary extends Fragment {


    ListView listView;
    CalendarView calendarView;
    String x;
    ArrayAdapter<String> adapter;
    ArrayList<String> arrayList;
    FirebaseFirestore base_get = FirebaseFirestore.getInstance();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_calendary, container, false);
        listView=rootView.findViewById(R.id.listview);
        calendarView=rootView.findViewById(R.id.calendarView_get);
        arrayList=new ArrayList<>();
        adapter=new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,arrayList);
        String eml = eml_global;
        listView.setAdapter(adapter);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                adapter.clear();
                adapter.notifyDataSetChanged();
                String data=(String.valueOf(year) +"_"+ String.valueOf(month) + "_"+ String.valueOf(dayOfMonth));
                System.out.println(eml);
                System.out.println(data);

                base_get.collection("users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {

                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {

                            for (QueryDocumentSnapshot document : task.getResult()) {
                                System.out.println(document.getId() + " => " + document.getData());
                                System.out.println("asdasddasdasd");
                                String s =document.getId();
                                base_get.collection("users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(s).collection("Information").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                    @Override
                                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                        if (task.isSuccessful()) {

                                            for (QueryDocumentSnapshot document : task.getResult()) {
                                                System.out.println(document.getId() + " => " + document.getData());
                                                String em = document.getData().toString();

                                                em="Время ="+s+","+em;
                                                System.out.println(em);
                                                adapter.add(em);
                                                adapter.notifyDataSetChanged();
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    }
                });
            }
        });
        return rootView;
    }
}