package com.example.diaryofemotions;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Firebase;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

public class MainActivity extends AppCompatActivity {
    String login_name;
    FirebaseAuth firebaseAuth;
    Button login, regist;
    EditText email,password;
    FirebaseFirestore firestore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        login=findViewById(R.id.loginbtn);
        regist=findViewById(R.id.registrbtn);
        email=findViewById(R.id.emailplaintext);
        password=findViewById(R.id.passwordplaintext);
        firebaseAuth=FirebaseAuth.getInstance();
        firestore=FirebaseFirestore.getInstance();
        regist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotoregistr = new Intent(MainActivity.this, registr.class);
                startActivity(gotoregistr);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String em= email.getText().toString();
                String pasw= password.getText().toString();
                if (em.equals("")){
                    Toast.makeText(MainActivity.this, "Почта пуста", Toast.LENGTH_SHORT).show();
                } else if (pasw.equals("")) {
                    Toast.makeText(MainActivity.this, "Пароль пуст", Toast.LENGTH_SHORT).show();
                }else {
                firebaseAuth.signInWithEmailAndPassword(em,pasw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {
                            firestore.collection("users").document(em.toLowerCase()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot document) {
                                    if (document.exists()) {
                                        Map<String, Object> data = document.getData();
                                        login_name = (String) data.get("Login");
                                        write_info(em,login_name);

                                    }
                                }
                            });
                            Toast.makeText(MainActivity.this, "Вы успешно вошли", Toast.LENGTH_SHORT).show();
                            Intent gotomenu = new Intent(MainActivity.this,base.class);
                            gotomenu.putExtra("a","no");
                            startActivity(gotomenu);
                        } else {
                            Toast.makeText(MainActivity.this, "Ошибка", Toast.LENGTH_SHORT).show();
                        }
                    }
                });}
            }
        });
    }

    private void write_info(@NonNull String em,String log) {
        ((global_variable) this.getApplication()).seteml(em.toLowerCase());
        ((global_variable) this.getApplication()).setlog(log);
    }


}