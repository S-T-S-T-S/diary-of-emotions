package com.example.diaryofemotions;

import static com.example.diaryofemotions.global_variable.log_global;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class firstmenuFragment extends Fragment  {
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_firstmenu, container, false);
        TextView name=rootView.findViewById(R.id.login_text);
        Button write =rootView.findViewById(R.id.writebtn);
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.frame_lau,new write_emotions_fr()).addToBackStack(null).commit();
            }
        });
        name.setText("Здравствуйте"+" "+log_global);

        return rootView;
    }




}