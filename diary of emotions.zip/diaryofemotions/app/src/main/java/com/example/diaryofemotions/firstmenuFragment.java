package com.example.diaryofemotions;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.app.Application;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;


public class firstmenuFragment extends Fragment  {
    private com.example.diaryofemotions.global_variable global_variable;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_firstmenu, container, false);
        TextView textView=rootView.findViewById(R.id.login_text);
        FirebaseFirestore user= FirebaseFirestore.getInstance();

        return rootView;

    }



}