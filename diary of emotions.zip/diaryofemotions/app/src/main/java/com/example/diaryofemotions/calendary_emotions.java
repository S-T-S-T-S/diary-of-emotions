package com.example.diaryofemotions;

import static com.example.diaryofemotions.global_variable.data_global;
import static com.example.diaryofemotions.global_variable.eml_global;
import static com.example.diaryofemotions.global_variable.emotion_global;
import static com.example.diaryofemotions.global_variable.how_much;
import static com.example.diaryofemotions.global_variable.log_global;
import static com.example.diaryofemotions.global_variable.what_you;
import static com.example.diaryofemotions.global_variable.who_this;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class calendary_emotions extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_calendary_emotions, container, false);
        CalendarView calendarView;
        EditText time;
        android.icu.util.Calendar calendar;
        Button  record;
        FirebaseFirestore user;
        calendarView = rootView.findViewById(R.id.calendarView_get);
        calendar = android.icu.util.Calendar.getInstance();

        record = rootView.findViewById(R.id.record);
        time = rootView.findViewById(R.id.editTextTime);
        user = FirebaseFirestore.getInstance();
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                data_global=((String.valueOf(year) +"_"+ String.valueOf(month) + "_"+ String.valueOf(dayOfMonth)));
            }
        });
        record.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                String eml = eml_global;
                String log = log_global;
                String data = data_global;
                String tim = "нечего";
                tim = tim + time.getText().toString();
                if (tim.equals("нечего")) {
//                    Toast.makeText(R.id.frame_lau ,"укажите время", Toast.LENGTH_SHORT).show();

                } else {
                    tim = tim.substring(6);
                    int lentime= tim.length();
                    if (lentime<=2){
//                        Toast.makeText(Calendar.this, "Не правильно указано время", Toast.LENGTH_SHORT).show();

                    } else {
                        if (lentime==3){
                            StringBuffer strBuffer = new StringBuffer(tim);
                            tim=String.valueOf(strBuffer.insert(1, ':'));

                        }else {
                            StringBuffer strBuffer = new StringBuffer(tim);
                            tim=String.valueOf(strBuffer.insert(2, ':'));
                        }

                        if (data == null) {
//                            Toast.makeText(Calendar.this, "Указалася сегодняшний день", Toast.LENGTH_SHORT).show();
                            java.util.Calendar c = java.util.Calendar.getInstance();
                            data = String.valueOf(c.get(java.util.Calendar.YEAR)) + "_" + String.valueOf(c.get(java.util.Calendar.MONTH)) + "_" + String.valueOf(c.get(java.util.Calendar.DAY_OF_MONTH));
                        }

                        Map<String, Object> tim_zag = new HashMap<>();
                        tim_zag.put("Tim", tim);
                        Map<String, Object> col = new HashMap<>();
                        col.put("Что вы испытывали", what_you);
                        col.put("На сколько сильна была эмоция", how_much);
                        col.put("Из за чего",who_this);
                        col.put("Ваша эмоция", emotion_global);



                        user.collection("users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(tim).collection("Information").add(col).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentReference> task) {
                                Toast.makeText(getActivity(), "Успешно", Toast.LENGTH_SHORT).show();
                            }
                        });
                        user.collection("users").document(eml.toLowerCase()).collection("Data").document(data).collection("Time").document(tim).set(tim_zag).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                tim_zag.clear();
                            }
                        });
                    }}



            }
        });
        return rootView;
    }
}