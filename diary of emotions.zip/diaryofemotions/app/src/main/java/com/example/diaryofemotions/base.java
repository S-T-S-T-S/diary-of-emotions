package com.example.diaryofemotions;

import android.annotation.SuppressLint;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;


public class base extends AppCompatActivity {
    ImageButton menubtn, infobtn,calbtn,settingsbtn;
    private com.example.diaryofemotions.global_variable global_variable;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_base);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        menubtn=findViewById(R.id.menubutton);
        infobtn=findViewById(R.id.infobutton);
        calbtn=findViewById(R.id.calenbutton);
        settingsbtn=findViewById(R.id.settingsbutton);
        fragmentinformation infofr =new fragmentinformation();
        setfragment(infofr);
        menubtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstmenuFragment menufragment=new firstmenuFragment();
                setfragment(menufragment);
            }
        });
        infobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setfragment(infofr);
            }
        });
        calbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calendary calendary=new calendary();
                setfragment(calendary);
            }
        });
        settingsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(base.this, "на данный момент функция не прописана", Toast.LENGTH_SHORT).show();
            }
        });
    }



    public void setfragment(Fragment fragment) {
        FragmentTransaction ft= getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frame_lau,fragment);
        ft.addToBackStack(null);
        ft.commit();
    }


}