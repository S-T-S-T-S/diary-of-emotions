package com.example.diaryofemotions;

import android.app.Application;

public class global_variable extends Application {
    public static String log_global;
    public static String eml_global;
    public static String data_global;

    public static String what_you;
    public static String who_this;
    public static String how_much;

    public void setlog(String someVariable) {
        this.log_global = someVariable;
    }
    public void seteml(String someVariable) {
        this.eml_global = someVariable;
    }
}

