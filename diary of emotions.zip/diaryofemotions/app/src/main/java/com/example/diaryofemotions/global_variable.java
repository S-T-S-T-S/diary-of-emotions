package com.example.diaryofemotions;

import android.app.Application;

public class global_variable extends Application {
    private String log;
    private String   eml;
    private String   data;

    public String getlog() {
        return log;
    }
    public String geteml() {
        return eml;
    }

    public void setlog(String someVariable) {
        this.log = someVariable;
    }
    public void seteml(String someVariable) {
        this.eml = someVariable;
    }
    public String getdata() {
        return data;
    }

    public void setData(String someVariable) {
        this.data = someVariable;
    }
}

