package com.example.diaryofemotions;

import static com.example.diaryofemotions.global_variable.emotion_global;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.Firebase;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link choice_emotion#newInstance} factory method to
 * create an instance of this fragment.
 */
public class choice_emotion extends Fragment {



    @SuppressLint("WrongViewCast")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_choice_emotion, container, false);
        ImageButton interes, beshemeteshnost,prinatie,trevoga,rasterenost,grust,skuka,dosada, smushenie;
        Firebase firebase;
        //2 столб
        ImageButton oshidanie,radost,doverie,strah,ydivlenie,pechal,neydovolstvie,zlost,stbid;

        //3 столб
        ImageButton nastoroshenost,vostorg,voshishenie,yshaz,uzymlenie,gore,otvroshenie,gnev,vina;
        interes = rootView.findViewById(R.id.interes);
        beshemeteshnost = rootView.findViewById(R.id.beshemeteshnost);
        prinatie = rootView.findViewById(R.id.prinatie);
        trevoga = rootView.findViewById(R.id.trevoga);
        rasterenost = rootView.findViewById(R.id.rasterenost);
        grust = rootView.findViewById(R.id.grust);
        skuka = rootView.findViewById(R.id.skuka);
        dosada = rootView.findViewById(R.id.dosada);
        smushenie = rootView.findViewById(R.id.smushenie);
        //эмоции ниже обьявляем
        //2 столбец
        oshidanie= rootView.findViewById(R.id.oshidanie);
        radost= rootView.findViewById(R.id.radost);
        doverie= rootView.findViewById(R.id.doverie);
        strah= rootView.findViewById(R.id.strax);
        ydivlenie= rootView.findViewById(R.id.ydivlenie);
        pechal= rootView.findViewById(R.id.pechal);
        neydovolstvie= rootView.findViewById(R.id.neydovolstvie);
        zlost= rootView.findViewById(R.id.zlost);
        stbid= rootView.findViewById(R.id.stbid);
        //эмоции ниже обьявляем
        //3 столбец
        nastoroshenost = rootView.findViewById(R.id.nastoroshenost);
        vostorg = rootView.findViewById(R.id.vostorg);
        voshishenie = rootView.findViewById(R.id.voshishenie);
        yshaz = rootView.findViewById(R.id.yshaz);
        uzymlenie = rootView.findViewById(R.id.uzymlenie);
        gore = rootView.findViewById(R.id.gore);
        otvroshenie = rootView.findViewById(R.id.otvroshenie);
        gnev = rootView.findViewById(R.id.gnev);
        vina = rootView.findViewById(R.id.vina);










        //слушатель 1 столбца

        interes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Интерес";

                pokaz();
            }
        });
        beshemeteshnost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Безмятежность";
                pokaz();
            }
        });
        prinatie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Принятие";
                pokaz();
            }
        });
        trevoga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Тревога";
                pokaz();
            }
        });
        rasterenost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Растерянность" ;
                pokaz();
            }
        });
        grust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Грусть";
                pokaz();
            }
        });
        skuka.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="скука";
                pokaz();
            }
        });
        dosada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global= "Досада";
                pokaz();
            }
        });
        smushenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Смущение";
                pokaz();
            }
        });





        //слушатель 2 столбца
        oshidanie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Ожидание";
                pokaz();
            }
        });
        radost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Радость";
                pokaz();
            }
        });
        doverie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Удивление";
                pokaz();
            }
        });
        strah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Страх";
                pokaz();
            }
        });
        ydivlenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Удивление";
                pokaz();
            }
        });
        pechal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Печаль";
                pokaz();
            }
        });
        neydovolstvie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Неудовольствие";
                pokaz();
            }
        });
        zlost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Злость";
                pokaz();
            }
        });
        stbid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Стыд";
                pokaz();
            }
        });






        //слушатель 3 столбца
        nastoroshenost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Настророженность";
                pokaz();
            }
        });
        vostorg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Восторг";
                pokaz();
            }
        });
        voshishenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Восхищение";
                pokaz();
            }
        });
        yshaz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Ужас";
                pokaz();
            }
        });
        uzymlenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Изумление";
                pokaz();
            }
        });
        gore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Горе";
                pokaz();
            }
        });
        otvroshenie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Отвращение";
                pokaz();
            }
        });
        gnev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Гнев";
                pokaz();
            }
        });
        vina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                emotion_global="Вина";
                pokaz();
            }


        });
        Button back;
        back=rootView.findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.frame_lau,new write_emotions_fr()).addToBackStack(null).commit();
            }
        });
        return rootView;
    }

    private void pokaz() {
        Toast.makeText(getActivity(),"Вы выбрали "+emotion_global,Toast.LENGTH_SHORT).show();

    }

}