package com.example.diaryofemotions;

import static com.example.diaryofemotions.global_variable.how_much;
import static com.example.diaryofemotions.global_variable.what_you;
import static com.example.diaryofemotions.global_variable.who_this;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;

import com.google.android.material.textfield.TextInputEditText;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link write_emotions_fr#newInstance} factory method to
 * create an instance of this fragment.
 */
public class write_emotions_fr extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_write_emotions_fr, container, false);
        TextInputEditText what=rootView.findViewById(R.id.whatyouedit),who=rootView.findViewById(R.id.whatwhoedit);
        SeekBar seekBar;
        what.setText(what_you);
        who.setText(who_this);
        seekBar=rootView.findViewById(R.id.seekBar);
        Button voprosbtn =rootView.findViewById(R.id.voprosbtn_emot);

        Button next =rootView.findViewById(R.id.nextbtn);
//        seekBar.setProgress(Integer.valueOf(how_much));
        voprosbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.frame_lau,new choice_emotion()).addToBackStack(null).commit();
                what_you= String.valueOf(what.getText());
                who_this= String.valueOf(who.getText());
                how_much=String.valueOf(seekBar.getProgress());
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().beginTransaction().replace(R.id.frame_lau,new calendary_emotions()).addToBackStack(null).commit();
                what_you= String.valueOf(what.getText());
                who_this= String.valueOf(who.getText());
                how_much=String.valueOf(seekBar.getProgress());
            }
        });
        return rootView;
    }
}