package com.example.diaryofemotions;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class registr extends AppCompatActivity {
    FirebaseAuth fAuth;
    Button registr, back;
    EditText login, email, password;
    FirebaseFirestore user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registr);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        fAuth = FirebaseAuth.getInstance();
        registr = findViewById(R.id.registr_registr);
        back = findViewById(R.id.backtojoin);
        login = findViewById(R.id.login_reg);
        email = findViewById(R.id.email_reg);
        password = findViewById(R.id.password_reg);
        user=FirebaseFirestore.getInstance();
        Map<String, Object> col = new HashMap<>();
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gotologin = new Intent(registr.this, MainActivity.class);
                startActivity(gotologin);
            }
        });
        registr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fAuth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            col.put("Login",login.getText().toString());
                            user.collection("users").document(email.getText().toString().toLowerCase()).set(col).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                }
                            });
                            Toast.makeText(registr.this, "Вы Успешно зарегистрировались", Toast.LENGTH_SHORT).show();
                            write_info(email.getText().toString().toLowerCase(),login.getText().toString());
                            Intent gotomenu = new Intent(registr.this,base.class);
                            Toast.makeText(registr.this, "Если вы зашли в первый раз перезайдите в приложение", Toast.LENGTH_SHORT).show();
                            startActivity(gotomenu);
                        } else {
                            Toast.makeText(registr.this, "Ошибка", Toast.LENGTH_SHORT).show();

                        }
                    }

                });
            }
        });

    }
    private void write_info(@NonNull String em,String log) {
        ((global_variable) this.getApplication()).seteml(em.toLowerCase());
        ((global_variable) this.getApplication()).setlog(log);
    }


}